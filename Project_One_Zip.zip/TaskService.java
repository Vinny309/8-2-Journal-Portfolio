package moduleFourMilestone;

import java.util.ArrayList;

public class TaskService {
	/* Contains a list of tasks */
	private ArrayList<Task> tasks;
	
	/* Default constructor */
	public TaskService() {
		tasks = new ArrayList<>();
	}
	/* Method to add Tasks to list */
	public boolean add(Task task) {
		boolean existingTask = false;
		for (Task c : tasks) {
			if (c.equals(task)) {
				existingTask = true;
			}
		}
		if(!existingTask) {
			tasks.add(task);
			System.out.println("Task Added to list.");
			return true;
		}
		else {
			System.out.println("Task presently exists.");
			return false;
		}
	}
	/* Method to remove Tasks from list */
	public boolean remove(String taskID) {
		for (Task c : tasks) {
			if (c.gettaskID().equals(taskID)) {
				tasks.remove(c);
				System.out.println("Task removed from list.");
				return true;
			}
		}
		System.out.println("Task does not exist.");
		return false;
	}
	/* Method to update Tasks from list */
	public boolean update(String taskID, String name, String description) {
		  for (Task c : tasks) {
			  if (c.gettaskID().equals(taskID)) {
			          if (!name.equals(""))
			        	  c.setname(name);
			    if (!description.equals(""))
			    	c.setdescription(description);
			
			System.out.println("Task updated");
			
			return true;
		}
		System.out.println("Task does not exist.");
		
	    }
		return false;
	}
}
		
