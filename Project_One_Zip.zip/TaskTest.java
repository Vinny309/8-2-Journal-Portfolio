package moduleFourMilestoneTests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;

import org.junit.jupiter.api.Test;

import moduleFourMilestone.Task;

class TaskTest {
	/* Test Task */
	@Test
	void testTask() {
		Task task = new Task ("12345", "Name", "Description");
		assertTrue(task.gettaskID().equals("12345"));
		assertTrue(task.getname().equals("Name"));
		assertTrue(task.getdescription().equals("Description"));
	}
	/* Test Task ID length, too long */
	@Test
	void testTaskIdToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task ("12345111111", "Name", "Description");});}
	
	/* Test Task Name, too long */
	@Test
	void testTaskNameToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("12345", "NameNameNameNameNameName", "Description");});}
	
	/* Test Task Description, too long */
	@Test
	void testContactLastNameToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("12345", "Name", "This description is too long for theallowed character structure.");});}
	
	/* Testing for Task ID null value */
	@Test
	void testTaskIDIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task(null, "Name", "Description");});}
	
	/* Testing for Name null value */
	@Test
	void testContactFirstNameIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("12345", null, "Description");});}
	
	/* Testing for Description null value */
	@Test
	void testContactLastNameIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("12345", "Name", null);});}
}