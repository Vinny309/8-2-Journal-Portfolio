package moduleFourMilestoneTests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import moduleFourMilestone.Task;

import moduleFourMilestone.TaskService;

class TaskServiceTest {
	
	/* Test to add Tasks */
	@Test
	public void testMethodAddPass() {
		TaskService cs = new TaskService();
		Task c1 = new Task ("Test1", "Steve Young", "NFL Quarterback, No.#8");
		Task c2 = new Task("Test2", "Ronnie Lott", "NFL Safety No.#42");
		Task c3 = new Task("Test3", "Jerry Rice", "NFL Wide Receiver No.#80");
		
		assertEquals(true, cs.add(c1));
		assertEquals(true, cs.add(c2));
		assertEquals(true, cs.add(c3));
	}
	
	/* Test to add Task, with false assertions */
	@Test
	public void testMethodAddFail() {
		TaskService cs = new TaskService();
		Task c1 = new Task ("Test1", "Steve Young", "NFL Quarterback,No.#8");
		Task c2 = new Task("Test2", "Ronnie Lott", "NFL Safety No.#42");
		Task c3 = new Task("Test3", "Jerry Rice", "NFL Wide ReceiverNo.#80");
		
		assertEquals(true, cs.add(c1));
		assertEquals(false, cs.add(c1));
		assertEquals(true, cs.add(c3));
		assertEquals(true, cs.add(c2));
	}
	
	/* Test to delete Tasks */
	@Test
	public void testMethodDeletePass() {
		TaskService cs = new TaskService();
		Task c1 = new Task ("Test1", "Steve Young", "NFL Quarterback,No.#8");
		Task c2 = new Task("Test2", "Ronnie Lott", "NFL Safety No.#42");
		Task c3 = new Task("Test3", "Jerry Rice", "NFL Wide ReceiverNo.#80");
		
		assertEquals(true, cs.add(c1));
		assertEquals(true, cs.add(c2));
		assertEquals(true, cs.add(c3));
		assertEquals(true, cs.remove("Test1"));
		assertEquals(true, cs.remove("Test2"));
	}
	/* Test to delete Tasks, with false assertions */
	@Test
	public void testMethodDeleteFail() {
		TaskService cs = new TaskService();
		Task c1 = new Task ("Test1", "Steve Young", "NFL Quarterback,No.#8");
		Task c2 = new Task("Test2", "Ronnie Lott", "NFL Safety No.#42");
		Task c3 = new Task("Test3", "Jerry Rice", "NFL Wide ReceiverNo.#80");
		
		assertEquals(true, cs.add(c1));
		assertEquals(true, cs.add(c3));
		assertEquals(true, cs.add(c2));
		assertEquals(false, cs.remove("Test4"));
		assertEquals(true, cs.remove("Test2"));
	}
	/* Test the update Tasks */
	@Test
	public void testUpdatePass() {
		TaskService cs = new TaskService();
		Task c1 = new Task ("Test1", "Steve Young", "NFL Quarterback,No.#8");
		Task c2 = new Task("Test2", "Ronnie Lott", "NFL Safety No.#42");
		Task c3 = new Task("Test3", "Jerry Rice", "NFL Wide ReceiverNo.#80");
		
		assertEquals(true, cs.add(c1));
		assertEquals(true, cs.add(c3));
		assertEquals(true, cs.add(c2));
		assertEquals(true, cs.update("Test2", "Ronnie Lott", "College and NFLHOF"));
		assertEquals(true, cs.update("Test3", "Jerry Rice", "Rated #1 overallgreastest NFL player"));
	}
	/* Test to update Tasks, with false assertions */
	@Test
	public void testUpdateFail() {
		TaskService cs = new TaskService();
		Task c1 = new Task ("Test1", "Steve Young", "NFL Quarterback,No.#8");
		Task c2 = new Task("Test2", "Ronnie Lott", "NFL Safety No.#42");
		Task c3 = new Task("Test3", "Jerry Rice", "NFL Wide ReceiverNo.#80");
		
		assertEquals(true, cs.add(c1));
		assertEquals(true, cs.add(c3));
		assertEquals(true, cs.add(c2));
		assertEquals(false, cs.update("Test4", "Fred Warner", "NFL LinebackerNo.#54"));
		assertEquals(true, cs.update("Test2", "Joe Montana", "NFL QuarterbackNo.#16"));
	}
}