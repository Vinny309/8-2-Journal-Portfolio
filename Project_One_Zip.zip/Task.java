package moduleFourMilestone;

public class Task {
	/* Variables */
	private String taskID;
	private String name;
	private String description;
	
	/* Constructors with parameters */
	public Task(String taskID, String name, String description) {
		// Task ID length less than 10 characters
		if(taskID == null || taskID.length() > 10) {
			throw new IllegalArgumentException("Invalid Task ID");
		}
		// Name length less than 20 characters
		if(name == null || name.length() >20) {
			throw new IllegalArgumentException("Invalid Name");
		}
		// Description length less than 50 characters
		if(description == null || description.length() > 50) {
			throw new IllegalArgumentException("Invalid Description");
		}
		this.taskID = taskID;
		this.name = name;
		this.description = description;
	}
	/* Accessors and Mutators */
	public String gettaskID() {
		return taskID;
	}
	public String getname() {
		return name;
	}
	public void setname(String name) {
		this.name = name;
	}
	public String getdescription() {
		return description;
	}
	public void setdescription(String description) {
		this.description = description;
	}
}