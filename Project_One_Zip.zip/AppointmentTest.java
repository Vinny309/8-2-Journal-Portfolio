package moduleFiveMilestoneTests;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import moduleFiveMilestone.Appointment;

class AppointmentTest {
	private Date presentDate = new Date(System.currentTimeMillis());
	@Test
	void testAppointment() {
		Appointment appt = new Appointment("12345", presentDate ,"Description");
		assertTrue(appt.getApptID().equals("12345"));
		assertTrue(appt.getDate().equals(presentDate));
		assertTrue(appt.getDescription().equals("Description"));
	}
	@Test
	void testAppointmentApptIDToLong() {
		/* Test for Appointment ID, too long */
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("1234511111111", presentDate, "Description");});
		}
	@Test
	void testAppointmentDescriptionToLong() {
		/* Test for Description, too long */
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("12345", presentDate, "This Description is toolong for the allowed character structure.");});
		}
	@Test
	void testAppointmentApptIDIsNull() {
		/* Test for Appointment ID Null */
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment(null, presentDate, "Description");});
	}
	@Test
	void testAppointmentDateIsNull() {
		/* Test for Appointment Date Null*/
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("12345", null, "Description");});
	}
	@Test
	void testAppointmentDescriptionIsNull() {/* Test for Description Null */Assertions.assertThrows(IllegalArgumentException.class, () -> {
		new Appointment("12345", presentDate, null);});
	}
	
}