package moduleFiveMilestoneTests;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;
import moduleFiveMilestone.AppointmentService;

import moduleFiveMilestone.Appointment;

class AppointmentServiceTest {
	
	Date presentDate = new Date();
	
	/* Test to add Appointments */
	@Test
	public void testMethodAddPass() {
		AppointmentService cs = new AppointmentService();
		Appointment c1 = new Appointment ("Test1", presentDate , "NFLQuarterback, No.#8");
		Appointment c2 = new Appointment("Test2", presentDate , "NFL SafetyNo.#42");
		Appointment c3 = new Appointment("Test3", presentDate , "NFL WideReceiver No.#80");
		assertEquals(true, cs.add(c1));
		assertEquals(true, cs.add(c2));
		assertEquals(true, cs.add(c3));
	}
	/* Test to add Appointments, with false assertions */
	@Test
	public void testMethodAddFail() {
		AppointmentService cs = new AppointmentService();
		Appointment c1 = new Appointment ("Test1", presentDate , "NFLQuarterback, No.#8");
		Appointment c2 = new Appointment("Test2", presentDate , "NFL SafetyNo.#42");
		Appointment c3 = new Appointment("Test3", presentDate , "NFL WideReceiver No.#80");
		assertEquals(true, cs.add(c1));
		assertEquals(false, cs.add(c1));
		assertEquals(true, cs.add(c3));
		assertEquals(true, cs.add(c2));
	}
	/* Test to delete Appointments */
	@Test
	public void testMethodDeletePass() {
		AppointmentService cs = new AppointmentService();
		Appointment c1 = new Appointment ("Test1", presentDate , "NFLQuarterback, No.#8");
		Appointment c2 = new Appointment("Test2", presentDate , "NFL SafetyNo.#42");
		Appointment c3 = new Appointment("Test3", presentDate , "NFL WideReceiver No.#80");
		assertEquals(true, cs.add(c1));
		assertEquals(true, cs.add(c2));
		assertEquals(true, cs.add(c3));
		assertEquals(true, cs.remove("Test1"));
		assertEquals(true, cs.remove("Test2"));
	}
	/* Test to delete Appointments, with false assertions */
	@Test
	public void testMethodDeleteFail() {
		AppointmentService cs = new AppointmentService();
		Appointment c1 = new Appointment ("Test1", presentDate , "NFLQuarterback, No.#8");
		Appointment c2 = new Appointment("Test2", presentDate , "NFL SafetyNo.#42");
		Appointment c3 = new Appointment("Test3", presentDate , "NFL WideReceiver No.#80");
		assertEquals(true, cs.add(c1));
		assertEquals(true, cs.add(c3));
		assertEquals(true, cs.add(c2));
		assertEquals(false, cs.remove("Test4"));
		assertEquals(true, cs.remove("Test2"));
	}
}